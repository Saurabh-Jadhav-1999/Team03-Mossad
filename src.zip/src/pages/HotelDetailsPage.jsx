import { HotelDetails } from "../components/hotelDetails/HotelDetails"

export const HotelDetailsPage = () => {
    return (
        <>
           <HotelDetails />
        </>
    )
}
