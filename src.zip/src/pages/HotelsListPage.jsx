import { HotelSearchList } from "../components/hotelSearchList/HotelSearchList"
import { SearchBar } from "../components/searchBar/SearchBar"
export const HotelsListPage = () => {
  return (
    <>
      <SearchBar/>
      <HotelSearchList />
    </>
  )
}
