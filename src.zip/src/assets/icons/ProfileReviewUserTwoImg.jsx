import React from "react";

export const ProfileReviewUserTwoImg = () => {
  return (
  <>
  <img src="../images/ProfileReviewUserTwoImg.png" />;
  </>
  );
};
